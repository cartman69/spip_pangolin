<?php
// This is a SPIP language file  --  Ceci est un fichier langue de SPIP
// extrait automatiquement de http://trad.spip.net/tradlang_module/nospam?lang_cible=fa
// ** ne pas modifier le fichier **

if (!defined('_ECRIRE_INC_VERSION')) return;

$GLOBALS[$GLOBALS['idx_lang']] = array(

	// E
	'erreur_jeton' => 'روي پيام شما نمي‌توان حساب كرد. ممنون مكرر فرماييد!',
	'erreur_spam' => 'نمي‌توان روي پيام شما حساب كرد!',
	'erreur_spam_doublon' => 'يك پيام شناخته شده موجود است!',
	'erreur_spam_ip' => 'نظرات زيادي به زيان كيفيت!',

	// F
	'forum_saisie_texte_info' => 'اين فرم ميان‌ برهاي اسپيپ  <code>[-&gt;url] {{gras}} {italique} &lt;quote&gt; &lt;code&gt;</code>و  كد اچ.تي.ام.ال را <code>&lt;q&gt; &lt;del&gt; &lt;ins&gt;</code> مي‌پذيرد . براي ساختن پارگراف فقط يك سطر خالي بگذاريد. '
);

?>
