<?php
// This is a SPIP language file  --  Ceci est un fichier langue de SPIP
// extrait automatiquement de http://trad.spip.net/tradlang_module/nospam?lang_cible=sk
// ** ne pas modifier le fichier **

if (!defined('_ECRIRE_INC_VERSION')) return;

$GLOBALS[$GLOBALS['idx_lang']] = array(

	// E
	'erreur_attributs_html_interdits' => 'Nie je povolené vkladať obrázky ani používať atribúty html <tt>class</tt> alebo <tt>style</tt>',
	'erreur_blacklist' => 'Zaradili vás na čiernu listinu, nemôžete posielať správy.',
	'erreur_jeton' => 'Vaša správa sa nedá posúdiť. Ďakujeme vám, že ju pošlete znova.',
	'erreur_spam' => 'Vaša správa sa nedá posúdiť.',
	'erreur_spam_doublon' => 'Rovnaká správa už existuje!',
	'erreur_spam_ip' => 'Príliš veľa komentárov znižuje kvalitu!',
	'erreur_url_deja_spammee' => 'V tejto správe sú podozrivé odkazy, ktoré vyzerajú ako spam. Ďakujeme vám za ich odstránenie.',

	// F
	'forum_saisie_texte_info' => 'Na formátovanie správy tento formulár akceptuje iba skratky SPIPu <code>[-&gt;url] {{tučné}} {kurzíva} &lt;quote&gt; &lt;code&gt;</code> &lt;cadre&gt;</cadre> a kód HTML <code>&lt;q&gt; &lt;del&gt; &lt;ins&gt;</code>. Ak chcete robiť odseky, jednoducho vynechajte niekoľko prázdnych riadkov.',

	// I
	'info_ip_suspecte' => 'Vaša IP adresa je podozrivá z vytvárania SPAMU. Ďakujeme, že potvrdíte svoj dobrý úmysel.',

	// L
	'label_message_licite' => 'Toto nie je nevhodná správa'
);

?>
