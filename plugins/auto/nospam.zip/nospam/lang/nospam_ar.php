<?php
// This is a SPIP language file  --  Ceci est un fichier langue de SPIP
// extrait automatiquement de http://trad.spip.net/tradlang_module/nospam?lang_cible=ar
// ** ne pas modifier le fichier **

if (!defined('_ECRIRE_INC_VERSION')) return;

$GLOBALS[$GLOBALS['idx_lang']] = array(

	// E
	'erreur_jeton' => 'غير قادر على مراعاة رسالتك. أشكركم للإعادة !',
	'erreur_spam' => 'غير قادر على الأخذ في الاعتبار لرسالتك !',
	'erreur_spam_doublon' => 'وجود رسالة مماثلة !',
	'erreur_spam_ip' => 'تعليقات كثيرة جدا هي على حساب الجودة !',

	// F
	'forum_saisie_texte_info' => 'لتنسيق رسالتك، لا تدعم هذه الاستمارة الا اختصارات SPIP مثل <code>[-&gt;url] {{أسود}} {مائل}&lt;quote&gt; &lt;رموز برمجية&gt;</code> &lt;إطار&gt;</cadre> وعلامات HTML كـ<code>&lt;q&gt; &lt;del&gt; &lt;ins&gt;</code>. لإنشاء فقرات، يكفي ترك أسطر فارغة.'
);

?>
