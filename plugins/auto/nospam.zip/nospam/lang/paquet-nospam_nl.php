<?php
// This is a SPIP language file  --  Ceci est un fichier langue de SPIP
// extrait automatiquement de http://trad.spip.net/tradlang_module/paquet-nospam?lang_cible=nl
// ** ne pas modifier le fichier **

if (!defined('_ECRIRE_INC_VERSION')) return;

$GLOBALS[$GLOBALS['idx_lang']] = array(

	// N
	'nospam_description' => 'Stop SPAM! Filter berichten zonder oprechte gebruikers ermee lastig te vallen.',
	'nospam_slogan' => 'Beperk het risico van SPAM in forums'
);

?>
