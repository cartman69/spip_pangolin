<?php
// This is a SPIP language file  --  Ceci est un fichier langue de SPIP
// extrait automatiquement de http://trad.spip.net/tradlang_module/paquet-nospam?lang_cible=en
// ** ne pas modifier le fichier **

if (!defined('_ECRIRE_INC_VERSION')) return;

$GLOBALS[$GLOBALS['idx_lang']] = array(

	// N
	'nospam_description' => 'Stop spam! Filter spam in messages, without nuisance to honest users.',
	'nospam_slogan' => 'Reduce the risk of spams in the forums'
);

?>
