<?php
// This is a SPIP language file  --  Ceci est un fichier langue de SPIP
// extrait automatiquement de http://trad.spip.net/tradlang_module/paquet-nospam?lang_cible=es
// ** ne pas modifier le fichier **

if (!defined('_ECRIRE_INC_VERSION')) return;

$GLOBALS[$GLOBALS['idx_lang']] = array(

	// N
	'nospam_description' => 'Detenga el spam! Filtro de spam en los mensajes, sin molestias a los usuarios honestos.',
	'nospam_slogan' => 'Limitar el riesgo de spams en los foros'
);

?>
