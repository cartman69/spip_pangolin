<?php
// This is a SPIP language file  --  Ceci est un fichier langue de SPIP
// extrait automatiquement de http://trad.spip.net/tradlang_module/paquet-menus?lang_cible=de
// ** ne pas modifier le fichier **

if (!defined('_ECRIRE_INC_VERSION')) return;

$GLOBALS[$GLOBALS['idx_lang']] = array(

	// M
	'menus_description' => 'Ohne das Plugin {{Menüs}} müssen alle Menüs in den Seitenskeletten definiert werden. Webmaster, die keinen Zugriff auf den Quellcode der Skelette haben, müssen in diesem Fall für jede Änderung den zuständigen Webdesigner oder Programmierer beauftragen. Direkte Links zu spezifischen Webseiten oder Objekten müssen fest in die Skelette eingetragen werden.

Mit dem Plugin {{Menüs}} können öffentliche Menüs im Redaktionsbereich über eine leicht bedienbare Oberfläche angelegt und bearbeitet werden. {{Achtung !}} Das Plugin kümmert sich nicht um die Formatierung der Menüs, welche separat z.B. per CSS-Code festgelegt wird. {{Menüs}} erzeugt den HTML-Code der Menüs.',
	'menus_nom' => 'Menüs',
	'menus_slogan' => 'Legen Sie eigene Menüs an',
	'menus_titre' => 'Menüs'
);

?>
