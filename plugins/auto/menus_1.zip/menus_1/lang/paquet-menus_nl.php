<?php
// This is a SPIP language file  --  Ceci est un fichier langue de SPIP
// extrait automatiquement de http://trad.spip.net/tradlang_module/paquet-menus?lang_cible=nl
// ** ne pas modifier le fichier **

if (!defined('_ECRIRE_INC_VERSION')) return;

$GLOBALS[$GLOBALS['idx_lang']] = array(

	// M
	'menus_description' => 'Wanneer je niet van de plugin {{Menus}} gebruik maakt, moeten alle menu’s in de skeletten worden opgebouwd.
	
	De plugin {{Menus}} laat toe om via de standaard interface van het privé-gedeelte de menu’s te bewerken.
	{{Let op!}} De plugin is niet bedoeld voor het stileren van een menu. Dat doe je met HTML en CSS.',
	'menus_nom' => 'Menu’s',
	'menus_slogan' => 'Maak persoonlijke menu’s.',
	'menus_titre' => 'Menus'
);

?>
