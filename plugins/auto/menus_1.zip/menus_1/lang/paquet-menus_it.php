<?php
// This is a SPIP language file  --  Ceci est un fichier langue de SPIP
// extrait automatiquement de http://trad.spip.net/tradlang_module/paquet-menus?lang_cible=it
// ** ne pas modifier le fichier **

if (!defined('_ECRIRE_INC_VERSION')) return;

$GLOBALS[$GLOBALS['idx_lang']] = array(

	// M
	'menus_description' => 'Crea i tuoi menù in redazione.', # MODIF
	'menus_slogan' => 'Crea i tuoi menù in redazione.',
	'menus_titre' => 'Menù'
);

?>
