<?php
// This is a SPIP language file  --  Ceci est un fichier langue de SPIP
// extrait automatiquement de http://trad.spip.net/tradlang_module/paquet-menus?lang_cible=es
// ** ne pas modifier le fichier **

if (!defined('_ECRIRE_INC_VERSION')) return;

$GLOBALS[$GLOBALS['idx_lang']] = array(

	// M
	'menus_description' => 'Cuando no se usa el plugin {{Menús}}, es necesario definir todos los menús en los esqueletos, lo que hace los administradores del sitio no puedan cambiar algo a su antojo, sino que deban solicitar a la persona modificar los esqueletos. Además, cuando vea los enlaces estáticos (un enlace a un artículo específico, o a una página determinada, o a un sitio externo)  deberá escribirlos en duro en el esqueleto del menú.
	El propósito del plugin {{Menús}} es entonces permitir elaborar fácilmente menús mediante una interfaz sencilla directamente en la parte privada. 
	{{¡Atención!}} Este plugin no se ocupa de cómo se mostrarán los menús. Permite crearlos fácilmente y generar el código HTML.',
	'menus_nom' => 'Menús',
	'menus_slogan' => 'Cree sus menús personalizados.',
	'menus_titre' => 'Menús'
);

?>
