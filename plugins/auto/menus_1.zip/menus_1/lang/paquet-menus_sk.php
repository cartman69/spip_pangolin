<?php
// This is a SPIP language file  --  Ceci est un fichier langue de SPIP
// extrait automatiquement de http://trad.spip.net/tradlang_module/paquet-menus?lang_cible=sk
// ** ne pas modifier le fichier **

if (!defined('_ECRIRE_INC_VERSION')) return;

$GLOBALS[$GLOBALS['idx_lang']] = array(

	// M
	'menus_description' => 'Keď sa nepoužíva zásuvný modul{{Menus,}} všetky šablóny musia byť definované v ich menu,
	čiže administrátori stránky to nemajú úplne pod kontrolou a ak chcú niečo zmeniť, musia sa obrátiť 
	na človeka, ktorý je zodpovedný za šablóny. Okrem toho ak chcete pridať statické odkazy (odkaz na konkrétny článok
	alebo na konkrétnu stránku, alebo na externú stránku), tie musia byť zapísané do šablóny menu.

	Cieľom zásuvného modulu {{Menus}} je umožniť vám ľahko vytvárať menu pomocou intuitívneho rozhrania priamo do súkromnej zóny.
	{{Pozor!}} Tento zásuvný modul sa nezaoberá tým, ako sa položky menu zobrazia. Umožňuje  ľahké vytváranie menu a vygenerovanie kódu HTML.',
	'menus_nom' => 'Ponuky menu',
	'menus_slogan' => 'Vytvorte svoje vlastné ponuky menu.',
	'menus_titre' => 'Ponuky menu'
);

?>
