<?php

// This is a SPIP language file  --  Ceci est un fichier langue de SPIP
if (!defined('_ECRIRE_INC_VERSION')) {
	return;
}

$GLOBALS[$GLOBALS['idx_lang']] = array(

	// A
	'spip_hop_description' => 'Ce plugin va agrandir la largeur de la page dans l\'espace privé de SPIP.',
	'spip_hop_nom' => 'Agrandir la largeur de page',
	'spip_hop_slogan' => 'Elargissez votre champ d\'action !',
);