<?php

// This is a SPIP language file  --  Ceci est un fichier langue de SPIP
if (!defined('_ECRIRE_INC_VERSION')) {
	return;
}

$GLOBALS[$GLOBALS['idx_lang']] = array(

	// A
	'spip_hop_description' => 'This plugin will increase the back office width.',
	'spip_hop_nom' => 'Increase the back office width',
	'spip_hop_slogan' => 'Increase your field of action !',
);