<?php

if (!defined('_ECRIRE_INC_VERSION')) {
	return;
}

$GLOBALS[$GLOBALS['idx_lang']] = array(

	// A
	'important' => 'Important :',

	//E
	'etendre_selection_bandeau' => 'Do you wish to keep the initial banner width ?',

	'explications' => 'The value must be followed by a unit : em, rem, px, %, pt.',

	'info_constante_definie' => 'A value has been defined for this field in a file <em>xxx_options.php</em>',

	// F
	'forcer_grand_ecran' => 'Force large display for every author ?',

	// O
	'options' => 'Options',

	//P
	'parametres' => 'Setting (Currently set to: "@ecran@")',

	//T
	'titre_page_configurer_spip_hop' => 'Settings for width display',

);