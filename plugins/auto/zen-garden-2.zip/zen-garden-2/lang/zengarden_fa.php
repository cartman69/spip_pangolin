<?php
// This is a SPIP language file  --  Ceci est un fichier langue de SPIP
// extrait automatiquement de http://trad.spip.net/tradlang_module/zengarden?lang_cible=fa
// ** ne pas modifier le fichier **

if (!defined('_ECRIRE_INC_VERSION')) return;

$GLOBALS[$GLOBALS['idx_lang']] = array(

	// A
	'apercevoir_ce_theme' => 'تماشا',

	// B
	'bandeau_personalisable' => 'مي‌توانيد تصوير سرصفحه‌ (بنر) اين تم را شخصي سازي كنيد',

	// C
	'choisir_ce_theme' => 'انتخاب',
	'choix_theme' => 'تم خود را انتخاب كنيد',

	// D
	'desactiver_ce_theme' => 'غيرفعال‌سازي و بازگشت به شيوه‌ي پيش‌گزيده',

	// I
	'info_page' => 'اين صفحه به شما امكان مديريت مناطق دسترسي محدود سايت شما را فراهم مي‌سازد',
	'intitule_compatiblite_squelette' => 'انطباق منحصر به فرد با اسكلت‌ها',
	'intitule_version' => 'نسخه',

	// S
	'switcher_activer' => 'فعال‌سازي سويچ تم‌ها روي سايت همگاني ',
	'switcher_desactiver' => 'فعال‌سازي سويچ تم‌ها',

	// T
	'theme_actif' => 'در حال حاضر اين تم مورد استفاده است',
	'themes' => 'تم‌ها'
);

?>
