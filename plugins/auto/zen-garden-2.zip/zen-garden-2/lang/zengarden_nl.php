<?php
// This is a SPIP language file  --  Ceci est un fichier langue de SPIP
// extrait automatiquement de http://trad.spip.net/tradlang_module/zengarden?lang_cible=nl
// ** ne pas modifier le fichier **

if (!defined('_ECRIRE_INC_VERSION')) return;

$GLOBALS[$GLOBALS['idx_lang']] = array(

	// A
	'apercevoir_ce_theme' => 'Verkennen',

	// B
	'bandeau_personalisable' => 'Je kunt de afbeelding in de banner van dit thema aanpassen',

	// C
	'choisir_ce_theme' => 'Keuze',
	'choix_theme' => 'Kies je thema',

	// D
	'desactiver_ce_theme' => 'Deactiveren en naar de standaardstijl terugkeren',

	// I
	'info_page' => 'Je kunt een aangeboden thema selecteren of bekijken hoe ze eruitzien zonder de weergave op de site voor bezoekers aan te passen',
	'intitule_compatiblite_squelette' => 'Uitsluitend compatibel met skeletten',
	'intitule_version' => 'versie',

	// S
	'switcher_activer' => 'Maak themakeuze mogelijk op de publieke site',
	'switcher_desactiver' => 'Maak themakeuze onmogelijk',

	// T
	'theme_actif' => 'Dit thema wordt momenteel gebruikt',
	'themes' => 'Thema’s'
);

?>
