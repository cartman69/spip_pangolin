<?php
// This is a SPIP language file  --  Ceci est un fichier langue de SPIP
// extrait automatiquement de http://trad.spip.net/tradlang_module/zengarden?lang_cible=sk
// ** ne pas modifier le fichier **

if (!defined('_ECRIRE_INC_VERSION')) return;

$GLOBALS[$GLOBALS['idx_lang']] = array(

	// A
	'apercevoir_ce_theme' => 'Zobraziť',

	// B
	'bandeau_personalisable' => 'Môžete si upraviť obrázok v pútači tohto farebného motívu',

	// C
	'choisir_ce_theme' => 'Vybrať',
	'choix_theme' => 'Vyberte si farebný motív',

	// D
	'desactiver_ce_theme' => 'Deaktivovať a vrátiť sa k predvolenému štýlu',

	// I
	'info_page' => 'Môžete si vybrať navrhovaný farebný motív alebo si nejaký jednoducho nechať zobraziť bez toho, aby sa tým zmenilo zobrazenie pre návštevníkov',
	'intitule_compatiblite_squelette' => 'Iba kompatibilné so šablónami',
	'intitule_version' => 'verzia',

	// S
	'switcher_activer' => 'Aktivovať prepínanie farebných tém na verejne prístupnej stránke',
	'switcher_desactiver' => 'Deaktivovať prepínanie farebných motívov',

	// T
	'theme_actif' => 'Tento farebný motív sa používa teraz',
	'themes' => 'Farebné motívy'
);

?>
