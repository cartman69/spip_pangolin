<?php
// This is a SPIP language file  --  Ceci est un fichier langue de SPIP
// extrait automatiquement de http://trad.spip.net/tradlang_module/zengarden?lang_cible=es
// ** ne pas modifier le fichier **

if (!defined('_ECRIRE_INC_VERSION')) return;

$GLOBALS[$GLOBALS['idx_lang']] = array(

	// A
	'apercevoir_ce_theme' => 'Previsualizar',

	// B
	'bandeau_personalisable' => 'Personalizar la imagen de la cabecera para este tema',

	// C
	'choisir_ce_theme' => 'Seleccionar',
	'choix_theme' => 'Seleccionar un tema',

	// D
	'desactiver_ce_theme' => 'Desactivar el tema y volver al estilo inicial del sitio',

	// I
	'info_page' => 'Puedes seleccionar uno de los temas propuestos, o sólo previsualizarlos sin modificar la visualización actual del sitio',
	'intitule_compatiblite_squelette' => 'Sólo es compatible con un esqueleto',
	'intitule_version' => 'versión',

	// S
	'switcher_activer' => 'Activar el switcher de temas en el sitio público',
	'switcher_desactiver' => 'Desactivar el switcher de temas',

	// T
	'theme_actif' => 'Este tema se utiliza actualmente',
	'themes' => 'Temas'
);

?>
