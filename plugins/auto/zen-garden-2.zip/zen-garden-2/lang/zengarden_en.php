<?php
// This is a SPIP language file  --  Ceci est un fichier langue de SPIP
// extrait automatiquement de http://trad.spip.net/tradlang_module/zengarden?lang_cible=en
// ** ne pas modifier le fichier **

if (!defined('_ECRIRE_INC_VERSION')) return;

$GLOBALS[$GLOBALS['idx_lang']] = array(

	// A
	'apercevoir_ce_theme' => 'Preview',

	// B
	'bandeau_personalisable' => 'You can customize the image in the banner of this theme',

	// C
	'choisir_ce_theme' => 'Choose',
	'choix_theme' => 'Choose your theme',

	// D
	'desactiver_ce_theme' => 'Deactivate and return to default style',

	// I
	'info_page' => 'You can choose one of the suggested theme or just see its rendering without changing the display for your visitors',
	'intitule_compatiblite_squelette' => 'Compatible only with the templates',
	'intitule_version' => 'version',

	// S
	'switcher_activer' => 'Activate the theme switcher on the public site',
	'switcher_desactiver' => 'Disable the themes switcher',

	// T
	'theme_actif' => 'This theme is currently used',
	'themes' => 'Themes'
);

?>
