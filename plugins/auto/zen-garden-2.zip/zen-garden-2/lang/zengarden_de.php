<?php
// This is a SPIP language file  --  Ceci est un fichier langue de SPIP
// extrait automatiquement de http://trad.spip.net/tradlang_module/zengarden?lang_cible=de
// ** ne pas modifier le fichier **

if (!defined('_ECRIRE_INC_VERSION')) return;

$GLOBALS[$GLOBALS['idx_lang']] = array(

	// A
	'apercevoir_ce_theme' => 'Vorschau',

	// B
	'bandeau_personalisable' => 'Sie können das Banner im Kopf des Themas anpassen',

	// C
	'choisir_ce_theme' => 'Auswählen',
	'choix_theme' => 'Bitte Thema auswählen',

	// D
	'desactiver_ce_theme' => 'Deaktivieren und Standarddesign wiederherstellen',

	// I
	'info_page' => 'Sie können entweder ein Thema aktivieren oder die Vorschau nutzen,
	wenn Sie das Aussehen der Website für Besucher nicht ändern möchten.',
	'intitule_compatiblite_squelette' => 'Design setzt eines dieser Skelette voraus',
	'intitule_version' => 'Version',

	// S
	'switcher_activer' => 'Öffentliches Themen-Menü aktivieren.',
	'switcher_desactiver' => 'Öffentliches Themen-Menü deaktivieren',

	// T
	'theme_actif' => 'Dieses Thema wird zur Zeit verwendet',
	'themes' => 'Themen'
);

?>
