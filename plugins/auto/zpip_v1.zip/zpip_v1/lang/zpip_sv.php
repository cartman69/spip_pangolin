<?php
// This is a SPIP language file  --  Ceci est un fichier langue de SPIP
// Fichier source, a modifier dans svn://zone.spip.org/spip-zone/_plugins_/_stable_/acces_restreint/lang/
if (!defined("_ECRIRE_INC_VERSION")) return;

$GLOBALS[$GLOBALS['idx_lang']] = array(

	// A

	// B

	// C

	'conception_graphique_par' => 'Design (c)',
	'commentaire' => 'kommentar',
	'commentaires' => 'kommentarer ',

	// D

	// I

	// L
	'lire_la_suite' => 'L&auml;s mer',
	'lire_la_suite_de' => ' om ',

	// M

	// P
	'personaliser_nav' => 'Skr&auml;ddarsy denna meny',

	// R

	// S
	'sous_licence' => 'under licens',

	// T

	// V

	// Z
);

?>
