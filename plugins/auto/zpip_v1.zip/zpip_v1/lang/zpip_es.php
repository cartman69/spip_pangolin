<?php
// This is a SPIP language file  --  Ceci est un fichier langue de SPIP
if (!defined("_ECRIRE_INC_VERSION")) return;

$GLOBALS[$GLOBALS['idx_lang']] = array(

	// A

	// B

	// C
	'conception_graphique_par' => 'Dise&ntilde;o gr&aacute;fico (c)',
	'commentaire' => 'comentario',
	'commentaires' => 'comentarios',

	// D

	// I

	// L
	'lire_la_suite' => 'Seguir leyendo',
	'lire_la_suite_de' => '',

	// M

	// P

	// R

	// S
	'sous_licence' => 'bajo Licencia',

	// T

	// V

	// Z
);

?>
