<?php
// This is a SPIP language file  --  Ceci est un fichier langue de SPIP
// Fichier source, a modifier dans svn://zone.spip.org/spip-zone/_plugins_/_stable_/acces_restreint/lang/
if (!defined("_ECRIRE_INC_VERSION")) return;

$GLOBALS[$GLOBALS['idx_lang']] = array(
	// A

	// B

	// C
	'conception_graphique_par' => 'Ontwerp (c)',
	'commentaire' => 'reactie',
	'commentaires' => 'reacties ',

	// D

	// I

	// L
	'lire_la_suite' => 'Lees meer',
	'lire_la_suite_de' => ' over ',

	// M

	// P
	'personaliser_nav' => 'Personaliseer dit menu',

	// R

	// S
	'sous_licence' => 'onder licensie',

	// T

	// V

	// Z
);

?>
