<?php
// This is a SPIP language file  --  Ceci est un fichier langue de SPIP
// Fichier source, a modifier dans svn://zone.spip.org/spip-zone/_plugins_/_stable_/acces_restreint/lang/
if (!defined("_ECRIRE_INC_VERSION")) return;

$GLOBALS[$GLOBALS['idx_lang']] = array(

	// A
	'adapte_de' => 'auf Grundlage von',
	// B

	// C
	'conception_graphique_par' => 'Design von (c)',
	'commentaire' => 'Kommentar',
	'commentaires' => 'Kommentare',

	// D

	// I

	// L
	'lire_la_suite' => 'Ganzer Text',
	'lire_la_suite_de' => ' von ',

	// M

	// P
	'personaliser_nav' => 'Men&uuml; anpassen',

	// R

	// S
	'sous_licence' => 'Lizenz: ',

	// T

	// V

	// Z
);

?>
