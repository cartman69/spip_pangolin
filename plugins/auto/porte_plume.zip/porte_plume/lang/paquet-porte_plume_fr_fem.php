<?php
// This is a SPIP language file  --  Ceci est un fichier langue de SPIP
// extrait automatiquement de http://trad.spip.net/tradlang_module/paquet-porte_plume?lang_cible=fr_fem
// ** ne pas modifier le fichier **

if (!defined('_ECRIRE_INC_VERSION')) {
	return;
}

$GLOBALS[$GLOBALS['idx_lang']] = array(

	// P
	'porte_plume_description' => 'Porte plume est une barre d’outils extensible pour SPIP qui utilise la bibliothèque javascript [MarkItUp->http://markitup.jaysalvat.com/home/]',
	'porte_plume_nom' => 'Porte plume',
	'porte_plume_slogan' => 'Une barre d’outils pour bien écrire'
);

?>
