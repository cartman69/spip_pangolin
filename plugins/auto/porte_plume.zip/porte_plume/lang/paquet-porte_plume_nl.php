<?php
// This is a SPIP language file  --  Ceci est un fichier langue de SPIP
// extrait automatiquement de http://trad.spip.net/tradlang_module/paquet-porte_plume?lang_cible=nl
// ** ne pas modifier le fichier **

if (!defined('_ECRIRE_INC_VERSION')) {
	return;
}

$GLOBALS[$GLOBALS['idx_lang']] = array(

	// P
	'porte_plume_description' => 'Penhouder is een rekbare werkbalk voor SPIP die gebruik van [MarkItUp->http://markitup.jaysalvat.com/home/] javascript library  maakt.',
	'porte_plume_nom' => 'Penhouder',
	'porte_plume_slogan' => 'Een penhouder om mooi te schrijven'
);

?>
