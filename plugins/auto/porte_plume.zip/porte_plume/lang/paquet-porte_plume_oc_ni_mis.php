<?php
// This is a SPIP language file  --  Ceci est un fichier langue de SPIP
// extrait automatiquement de http://trad.spip.net/tradlang_module/paquet-porte_plume?lang_cible=oc_ni_mis
// ** ne pas modifier le fichier **

if (!defined('_ECRIRE_INC_VERSION')) {
	return;
}

$GLOBALS[$GLOBALS['idx_lang']] = array(

	// P
	'porte_plume_description' => 'Pouòrta-pluma es una barra d’óutis estensible per SPIP qu’utilisa la biblioutèca javascript [MarkItUp->http://markitup.jaysalvat.com/home/]',
	'porte_plume_nom' => 'Pouòrta-pluma',
	'porte_plume_slogan' => 'Una Barra d’óutis da ben escriéure'
);

?>
