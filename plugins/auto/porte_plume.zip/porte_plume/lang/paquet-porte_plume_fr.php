<?php
// This is a SPIP language file  --  Ceci est un fichier langue de SPIP
// Fichier source, a modifier dans svn://zone.spip.org/spip-zone/_core_/plugins/porte_plume/lang/
if (!defined('_ECRIRE_INC_VERSION')) {
	return;
}

$GLOBALS[$GLOBALS['idx_lang']] = array(

	// P
	'porte_plume_description' => 'Porte plume est une barre d’outils extensible pour SPIP qui utilise la bibliothèque javascript [MarkItUp->http://markitup.jaysalvat.com/home/]',
	'porte_plume_nom' => 'Porte plume',
	'porte_plume_slogan' => 'Une barre d’outils pour bien écrire'
);

?>
