<?php
// This is a SPIP language file  --  Ceci est un fichier langue de SPIP
// extrait automatiquement de http://trad.spip.net/tradlang_module/paquet-porte_plume?lang_cible=sk
// ** ne pas modifier le fichier **

if (!defined('_ECRIRE_INC_VERSION')) {
	return;
}

$GLOBALS[$GLOBALS['idx_lang']] = array(

	// P
	'porte_plume_description' => 'Porte plume je rozšíriteľný panel s nástrojmi pre SPIP, ktorý využíva javascriptovú knižnicu [MarkItUp->http://markitup.jaysalvat.com/home/]',
	'porte_plume_nom' => 'Porte plume',
	'porte_plume_slogan' => 'Panel s nástrojmi, vďaka ktorému môžete vylepšiť svoje texty'
);

?>
