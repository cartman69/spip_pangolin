<?php
// This is a SPIP language file  --  Ceci est un fichier langue de SPIP
// extrait automatiquement de http://trad.spip.net/tradlang_module/paquet-porte_plume?lang_cible=en
// ** ne pas modifier le fichier **

if (!defined('_ECRIRE_INC_VERSION')) {
	return;
}

$GLOBALS[$GLOBALS['idx_lang']] = array(

	// P
	'porte_plume_description' => 'The Quill is a SPIP extensible toolbar which uses the [MarkItUp->http://markitup.jaysalvat.com/home/] javascript library.',
	'porte_plume_nom' => 'Quill',
	'porte_plume_slogan' => 'A toolbar to enhance your texts'
);

?>
